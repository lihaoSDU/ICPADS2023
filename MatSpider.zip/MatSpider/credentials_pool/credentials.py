# log in after filling in the user info
# and store the info in credentials.json.
#
# Note: run as a script.
# TODO:
# LAST MODYFIED : 2022 / 11 / 12

import json
import sys
import asyncio

from nio import AsyncClient
from nio import LoginResponse

CONFIG_FILE = "credentials.json"

###################### Change the User Info Here ##################################
"""
homeserver = "http://127.0.0.1:8008"
user_id = "@m_algery:leohoo.xyz"
device_name = "matrix-nio"
pw = "wuyanbo123456"
"""

homeserver = "https://matrix.org"
user_id = "@wyb_:matrix.org"
device_name = "matrix-imac"
pw = "wuyanbo123456"
###################################################################################


async def client_login() -> None:
    """ generate credentials.json and log into the Homeserver.

    """
    
    client = AsyncClient(homeserver, user_id)
    print("login waiting")
    resp = await client.login(pw, device_name=device_name)

    # check that we logged in successfully
    if (isinstance(resp, LoginResponse)):
        write_details_to_disk(CONFIG_FILE, resp, homeserver)
    else:
        print(f"homeserver = \"{homeserver}\"; user = \"{user_id}\"")
        print(f"Failed to log in: {resp}")
        sys.exit(1)

    print("Logged in using a password. Credentials were stored.")
    await client.close()


def write_details_to_disk(CONFIG_FILE, resp: LoginResponse, homeserver) -> None:
    """ Writes the required login details to disk so we can log in later without using a password.

    Args:
        resp {LoginResponse} -- the successful client login response.
        homeserver -- URL of homeserver, e.g. "https://matrix.example.org"

    """
    # open the config file in write-mode
    with open(CONFIG_FILE, "w") as f:
        # write the login details to disk
        json.dump(
            {
                "homeserver": homeserver,
                "user_id": resp.user_id,
                "device_id": resp.device_id,
                "access_token": resp.access_token
            },
            f
        )

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(client_login())
