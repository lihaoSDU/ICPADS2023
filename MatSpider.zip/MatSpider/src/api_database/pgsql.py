# Implementation of Read/Write/Utility 
# Spider_PGSQL class, based on psycopg2.
# Running as one script is supported.
#
# TODO : 
# LAST MODYFIED : 2022 / 11 / 28

import psycopg2
from psycopg2.extras import execute_values

from typing import *
from time import strftime, localtime


# Run as a script
if __name__ == "__main__": 
    from query import *
else:
    from .query import *


############# sql info #############
sql_database = "nio"
sql_user = "nio"
sql_password = "nio"
sql_host = "XX.XX.XX.XX"
sql_port = "5432"

if sql_password == None:
    print("Fill in the info in pgsql.py")
    exit(1)

####################################


class Spider_PGSQL:
    ######################## Init ########################     
    def __init__(self) -> None:
        """ Establish a connection, initialize control data, 
        put initial records into the data table.
        
        TODO:
            1. Prevent disconnects from 
                causing program interruptions.
            2. [execute_values] for greater efficiency.
            
        """
        # An exception will be raised if the connection fails.
        self.conn = psycopg2.connect(
            database=sql_database, 
            user=sql_user, password=sql_password, 
            host=sql_host, port=sql_port
        )

        # Num - number of the table
        # Offset - offset of the processing room or HS.
        self.table = ['curRooms', 'server', 'uid', 'roomid']
        self.curRoomsNum = 0
        self.serverNum = 0
        self.recount('server')
        self.curRoomsOffset = -1
        self.curServerOffset = 0

        # not Running as a script
        if not __name__ == "__main__":
            self.addServers(['leohoo.xyz', 't2bot.io'])
            self.addServers(['gitter.im', 'matrix.org'])


    def __del__(self) -> None:
        """
        Note:
            do not create any object here.
        """
        self.conn.close()
    

    def __execute_Query_Fetchall(self, query: str)-> Any:
        """ do pgsql execute
        
        """
        cur = self.conn.cursor()
        cur.execute(query)
        return cur.fetchall()


    def changeServerOffset(self, ptr: int):
        """ change control data.
        
        """
        self.curServerOffset = ptr


    ######################## Select ########################
    def getNextServer(self) -> Union[None, str]:
        """ get the next HS from the 'server' table.

        Ret:
            str or None for no more servers
        """

        # check if no more servers
        if self.curServerOffset + 1 == self.serverNum:
            return None  

        self.curServerOffset += 1
        query = QUERY_getNextServer.format(self.curServerOffset)
        ret = self.__execute_Query_Fetchall(query)
        ret = ret[0][0]
        print('-' * 20, ret)

        return ret


    def getNextRoom(self, curTargetServer=None) -> Union[None, str]:
        """ get the next roomid from the 'roomid' table. If the roomid 
        belongs to curTargetServer, it will be returned. Otherwise,
        it will be ignored at this time.

        Args:
            if curTargetServer is None, no roomid will be ignored,
            which is useful when processing customized dataset.
        
        """
        # check If no more Rooms
        if self.curRoomsOffset + 1 == self.curRoomsNum:
            return None
        
        # Get the next roomID depending on curTargetServer.
        self.curRoomsOffset += 1
        query = QUERY_getNextRoom.format(self.curRoomsOffset)
        ret = self.__execute_Query_Fetchall(query)
        roomID: str = ret[0][0]
        serverOfRoomID = roomID.split(":")[1]

        if (curTargetServer == serverOfRoomID or curTargetServer == None):
            print("Analyse {}".format(roomID))
            return roomID
        else:
            # Recursive coding method.
            # save serverOfRoomID to datebse.
            self.addServers([serverOfRoomID])
            return self.getNextRoom(curTargetServer)


    def getUnvisitedRoom(self) -> List:
        """ Some rooms belonging to HS A are found at HS B.
        The function is aimed to find them.

        """
        query = "SELECT roomid from roomid where visited=false;"
        # ret format - [(id, ), (id, )...]
        ret = self.__execute_Query_Fetchall(query)

        roomid = [ele[0] for ele in ret]
        return roomid


    def getRoomUserNum(self, roomid) -> int:
        """ get the user number of a room.
        
        """
        ret = self.__execute_Query_Fetchall(QUERY_roomUserNum.format(roomid))
        return ret[0][0]


    ######################## Count ########################
    def recount(self, tableName: str) -> None:
        """ Correct the control data, which is used
        when there is some Pre-set data in datebase.

        """
        query = QUERY_count.format(tableName)
        ret = self.__execute_Query_Fetchall(query)

        if tableName == 'server':
            self.serverNum = ret[0][0]
        elif tableName == 'curRooms':
            self.curRoomsNum = ret[0][0]
        else:
            print("tableName is invalid")
            exit(1)


    def countUnvisited(self) -> int:
        """ count the unvisited rooms we 
        ignore in getNextRoom().
        
        """
        query = "select count(*) From roomid where visited=false;"
        ret = self.__execute_Query_Fetchall(query)
        return ret[0][0]


    ######################## Insert ########################
    def addServers(self, servers: List) -> None:
        """ add servers to the 'server' table.
        
        """
        cur = self.conn.cursor()
        for server in servers:
            cur.execute(QUERY_insertServer.format(server))
        self.conn.commit()
        
        self.recount('server')


    def addRooms(self, batch_rooms: List) -> None:
        """ add room to the 'roomid' and 'currooms' table.
        'roomid' table is for recording.
        
        """
        cur = self.conn.cursor()
        for roomID, num_members in batch_rooms:
            # the table 'currooms'
            cur.execute(QUERY_insertRooms.format(roomID))
            # the table 'roomid'
            cur.execute(QUERY_recordRoomID.format(
                roomID.split(':')[1], 
                roomID,
                num_members
                ))
        self.conn.commit()
        
        self.recount('curRooms')


    def addUids(self, user_ids: List) -> None:
        """ add uid to the 'uid' table.

        """
        cur = self.conn.cursor()
        for user_id in user_ids:
            cur.execute(QUERY_recordUid.format(user_id[0], user_id[1]) )
        self.conn.commit()


    ######################## Update ########################
    def updateServerInfo(self, server: str, opid: "int"=-1) -> None:
        """ change server's info in the 'server' table
        according to the opid.
        
        """
        if server == None:
            return

        if opid == -1:
            content = "complete=true"
        elif opid == 0:
            content = "getroom=true"
        elif opid == 1:
            content = "forbidden=true"
        else:
            exit(1)

        cur = self.conn.cursor()
        cur.execute(QUERY_updateServerInfo.format(content, server))
        self.conn.commit()

    
    def updateRoomVisited(self, roomID: str) -> None:
        """ mark the room as a visited room.

        """
        cur = self.conn.cursor()
        cur.execute(QUERY_updateRoomInfo.format("visited=true", roomID))
        self.conn.commit()


    def updateBridgeRoom(self, roomID: str) -> None:
        """ mark the roomid as a special bridge room
        in the table 'roomid'.
        
        """
        cur = self.conn.cursor()
        cur.execute(QUERY_updateRoomInfo.format("bool_bridge_room=true", roomID))
        self.conn.commit()


    ######################## Clear ########################
    def clearTable(self, tableName: str) -> None:
        """ reset the specified table and its control data.
        
        """
        cur = self.conn.cursor()
        cur.execute(QUERY_clear.format(tableName))
        self.conn.commit()
        
        if tableName == 'curRooms':
            self.curRoomsNum = 0
            self.curRoomsOffset = -1
        elif tableName == 'server':
            self.serverNum = 0
            self.curServerOffset = 0


    ######################## Backup ########################
    def backup(self) -> None:
        """ do backup on all tables.
        
        """
        cur = self.conn.cursor()
        time = strftime("%m%d%H%M", localtime()) + '_'

        for tableName in self.table:
            query = QUERY_backup.format("backup" + time + tableName, tableName)
            print(query)
            cur.execute(query)
        self.conn.commit()
        print("Back up Successfully")
        


if __name__ == "__main__":
    # check the control data.
    pg = Spider_PGSQL()
    pg.changeServerOffset(78)
    print(pg.getNextServer())

    # backup
    # pg = Spider_PGSQL()
    # pg.backup()
