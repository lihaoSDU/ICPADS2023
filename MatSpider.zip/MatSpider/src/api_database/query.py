# TRUNCATE TABLE currooms, roomid, server, uid RESTART IDENTITY;

# Select
QUERY_getNextServer    = "SELECT server From server   ORDER BY id ASC OFFSET {} LIMIT 1;"
QUERY_getNextRoom      = "SELECT roomid From currooms ORDER BY id ASC OFFSET {} LIMIT 1;"
QUERY_count            = "SELECT count(*) From {};"
QUERY_roomUserNum      = "SELECT nums_member from roomid where roomid='{}';"

# Insert
QUERY_recordUid        = "INSERT INTO uid VALUES ('{}','{}') ON CONFLICT(uid) DO NOTHING;"
QUERY_recordRoomID     = "INSERT INTO roomid (server, roomid, nums_member) VALUES ('{}', '{}', {}) ON CONFLICT(roomid) DO NOTHING;"
QUERY_insertServer     = "INSERT INTO server (server)   VALUES ('{}') ON CONFLICT(server) DO NOTHING;"
QUERY_insertRooms      = "INSERT INTO curRooms (RoomID) VALUES ('{}') ON CONFLICT(roomID) DO NOTHING;"

# Update
QUERY_updateServerInfo = "UPDATE server SET {} WHERE server='{}';"
QUERY_updateRoomInfo   = "UPDATE roomid SET {} WHERE roomid='{}';"

# Clear
QUERY_clear            = 'TRUNCATE TABLE {} RESTART IDENTITY;'

# Backup
QUERY_backup           = 'CREATE table {} as (select * From {});'
