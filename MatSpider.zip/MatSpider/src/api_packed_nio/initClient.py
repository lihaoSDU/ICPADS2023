# Create a customized AsyncClient object
# based on nio.
#
# TODO:
# LAST MODYFIED : /

import json
import os

from nio import AsyncClient, AsyncClientConfig
from nio import DiscoveryInfoResponse

CONFIG_FILE = "credentials.json"


async def create_nioClient() -> AsyncClient:
    """get user data and create AsyncClient object.

    Note:
        Based on the continuous testing, following the timeout
        values are efficient for the spider. 
    
    """
    obj_config = AsyncClientConfig
    obj_config.max_timeouts = 3
    obj_config.request_timeout = 300

    if not os.path.exists(CONFIG_FILE):
        print("No credential file.")
        exit(1)

    with open(CONFIG_FILE, "r") as f:
        config = json.load(f)
        client = AsyncClient(config['homeserver'], config=obj_config)
        client.access_token = config['access_token']
        client.user_id = config['user_id']
        client.device_id = config['device_id']

    # Actual HS url
    resp_actualUrl = await client.discovery_info()
    if isinstance(resp_actualUrl, DiscoveryInfoResponse):
        client.homeserver = resp_actualUrl.homeserver_url
    
    return client
