# Wrap matrix-nio to adapte to
# our matrix-spider strategy. 
#
# TODO:
# LAST MODYFIED : 2022 / 11 / 15


from nio import AsyncClient
from nio import (
    JoinResponse, 
    JoinedMembersResponse, 
    JoinError, 
    JoinedMembersError
    )
from ..api_utility import errorLog


async def nio_join(Client: AsyncClient, roomID) -> bool:
    """ join with timeout and error recording strategies.

    Ret:
        False: HS deny or timeout.

    """
    resp_join = await Client.join(roomID)

    # join rejected
    if isinstance(resp_join, JoinError):
        errorLog(
            ["Join", roomID, '|', 
            resp_join.status_code, resp_join.message]
            )
        return False

    # join timeout
    if resp_join == None:
        errorLog(["Join-Timeout", roomID])
        return False
    
    return True


async def nio_members(Client: AsyncClient, roomID, no_join=False):
    """ get members in one room with timeout 
    and error recording strategies.

    Args:
        no_join: Most bridge rooms is allowed to get its
        members without joining. if there's no join before,
        error info will not be recorded, because it can be a 
        normal room. This is also one way to identify the 
        bridge rooms.

    Ret:
        resp_members: HS accepts the request and no timeout.

    """
    resp_members = await Client.joined_members(roomID)

    # timeout
    if resp_members == None:
        errorLog(["Members-Timeout", roomID])
        return False

    # rejected
    if not isinstance(resp_members, JoinedMembersResponse):
        if no_join == False:
            errorLog(
                ["Members-after-Join", roomID, '|', 
                resp_members.status_code, resp_members.message]
            )
        return False
    
    # record bridge rooms.
    if no_join == True:
        errorLog(["Special bridge room", roomID])
    return resp_members


async def nio_forgetRoom(Client: AsyncClient, roomID: str):
    """ tell HS we don't need the room anymore.
    Note:
        Do not receive useless return values to
        save CPU time.

    """
    await Client.room_forget(roomID)
