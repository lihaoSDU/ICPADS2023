# Write errors and important infomation
# into ERROR_FILE.
#
# TODO:
# LAST MODYFIED : /

from time import strftime, localtime
from typing import List


ERROR_FILE = r'Error.log'


def errorLog(info: List[str]) -> None:
    time = strftime("%Y-%m-%d %H:%M:%S", localtime()) + '\n'
    with open(ERROR_FILE, 'a') as f:
        for ele in info:
            f.write(str(ele) + ' ')
        f.write(time)


def completeLog(count_unvisited: int) -> None:
    time = strftime("%Y-%m-%d %H:%M:%S", localtime())
    with open(ERROR_FILE, 'a') as f:
        f.write(time + ' Complete\n')
        f.write(str(count_unvisited) + " rooms still unvisited.\n")


def recordUnvisitedRoom(roomid_unvisited: List) -> None:
    length = len(roomid_unvisited)
    print('\n')
    print('-' * 20)

    print(str(length) + " rooms still unvisited.\n")
    print("Start to check :\n")
    for ele in roomid_unvisited:
        print("  {}\n".format(str(ele)))
        
    print('-' * 20)
    print('\n')


"""
# log in Error.log
def recordUnvisitedRoom(roomid_unvisited: List) -> None:
    length = len(roomid_unvisited)
    with open(ERROR_FILE, 'a') as f:
        f.write('\n')
        f.write('-' * 20)

        f.write(str(length) + " rooms still unvisited.\n")
        f.write("Start to check :\n")
        for ele in roomid_unvisited:
            f.write("  {}\n".format(str(ele)))

        f.write('-' * 20)
        f.write('\n')
"""
