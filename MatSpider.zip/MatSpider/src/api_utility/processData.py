# filtering uid, extracting roomid...
#
# TODO:
# LAST MODYFIED : /

from typing import List


def extract_HS_From_UsrInfo(ret: List) -> List:
    """ extract user info from nio datatype resp_members.
    
    """
    servers = set()
    user_ids = []

    for usrInfo in ret.members:
        # uid format: @alice:matrix.org
        uid = usrInfo.user_id
        server = uid.split(':')[1]
        user_id = (server, uid)

        servers.add(server)
        user_ids.append(user_id)

    servers.discard('leohoo.xyz')
    return list(servers), user_ids
