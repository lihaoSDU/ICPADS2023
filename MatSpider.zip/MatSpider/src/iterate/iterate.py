# Different iteration strategies on server/room, 
# based on the low-level API we have constructed.
# 
# TODO:
# LAST MODYFIED : 2022 / 11 / 15


from typing import *

from ..store_data import *

from ..api_packed_nio import create_nioClient
from ..api_database import Spider_PGSQL
from ..api_utility import *

from nio import AsyncClient


async def init_iteration():
    """ create AsyncClient, Spider_PGSQL object.
    
    """
    client: AsyncClient = await create_nioClient()
    pgsql = Spider_PGSQL()

    return client, pgsql


async def end_of_iteration(client: AsyncClient, pgsql: Spider_PGSQL) -> None:
    """ close the connection, backup data...
    
    """
    completeLog(pgsql.countUnvisited())
    # pgsql close connection automaticly
    pgsql.backup()
    await client.close()


def custom_control_data(pgsql: Spider_PGSQL, startfrom: int):
    """ custom database control data
    
    """

    pgsql.changeServerOffset(startfrom) 


async def iterate_Tserver(client: AsyncClient, pgsql: Spider_PGSQL) -> None:
    """ Iterate HS in 'server' table to find more HSs, 
    until there's no more data.
    
    """
    remoteHS = pgsql.getNextServer()

    while remoteHS != None:
        # get the public rooms in remoteHS.
        getPublicRooms_status: int = collect_publicRooms(remoteHS, pgsql)
        
        if  getPublicRooms_status == 0:
            print("*** {} has {} public rooms.".format(remoteHS, pgsql.curRoomsNum))
            await visit_rooms_in_Troomid(client, pgsql, remoteHS)
        else:
            print("*** Could not get {} public rooms - {}".format(remoteHS, getPublicRooms_status))

        # process next HS.
        remoteHS = pgsql.getNextServer()


async def visit_unvisited_rooms(client: AsyncClient, pgsql: Spider_PGSQL) -> None:
    """ collect all unvisited rooms into the 'roomid' table,
    visit them to find more HSs.

    """
    roomid_unvisited = pgsql.getUnvisitedRoom()
    recordUnvisitedRoom(roomid_unvisited)
    pgsql.addRooms(roomid_unvisited)

    await visit_rooms_in_Troomid(client, pgsql, remoteHS=None)


async def visit_rooms_in_Troomid(client: AsyncClient, pgsql: Spider_PGSQL, remoteHS: str) -> None:
    """ visit rooms in 'roomid' table to find more HSs.

    Note:
        We get the room's members first to check if it's
        a bridge room. See members.py for more.

    """
    roomID = pgsql.getNextRoom(remoteHS)

    while roomID:
        # check bridge room
        if not await get_members_directly(client, pgsql, roomID):
            # not a bridge room.
            await get_members_via_Join(client, pgsql, roomID)

        pgsql.updateRoomVisited(roomID)
        
        roomID = pgsql.getNextRoom(remoteHS)

    pgsql.updateServerInfo(remoteHS)
    pgsql.clearTable('curRooms')
