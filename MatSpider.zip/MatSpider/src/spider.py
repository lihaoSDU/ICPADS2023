# Matrix spider, aimed to discover more matirx HS.
# It's based on the high-level API we have constructed.
#
# TODO:
# LAST MODYFIED : 2022 / 11 / 07

from .iterate import *


async def spider():
    """ Core steps of matrix-spider

    Note:
        The experimental results show that there will
        be few unvisited rooms after the second round.

    """
    client, pgsql = await init_iteration()

    # first iteration.
    # optional : custom the offset where we start from.
    custom_control_data(pgsql, 0)
    await iterate_Tserver(client, pgsql)

    # visit unvisited room
    visit_unvisited_rooms(client, pgsql)

    # second iteration.
    # It's designed for the servers found
    # in visit_unvisited_rooms() above.
    # There is usually no more data to processed
    # after the second iteration.
    await iterate_Tserver(client, pgsql)

    await end_of_iteration(client, pgsql)


if __name__ == "__main__":
    import asyncio
    asyncio.get_event_loop().run_until_complete(spider())
