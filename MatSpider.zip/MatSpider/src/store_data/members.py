# To obtain the user list of one room, we
# can join the room after calling /joined_members
# API. However, getting a user List without joining
# is allowed for a large number of bridge rooms.
# Thus, two types of API are implemented, based on 
# the low-level API constructed in api directories.
#
# TODO:
# LAST MODYFIED: 2022 / 11 / 15

from ..api_packed_nio import nio_join, nio_members
from ..api_database import Spider_PGSQL
from ..api_utility import extract_HS_From_UsrInfo


async def get_members_via_Join(Client, pgsql: Spider_PGSQL, roomID: str) -> None: 
    """ join the room and get its user list.

    Note:
        We remove the reception of useless return 
        values to save CPU time.
        
    """
    # API - Join
    join_success: bool = await nio_join(Client, roomID)

    if join_success:
        resp_members = await nio_members(Client, roomID)
        if resp_members != False:
            servers, user_ids = extract_HS_From_UsrInfo(resp_members)

            print("    Get new servers {}".format(len(servers)) )
            pgsql.addServers(servers)
            pgsql.addUids(user_ids)

    # leave the "small" rooms only.
    if pgsql.getRoomUserNum(roomID) < 12000:
        await Client.room_leave(roomID)
        await Client.room_forget(roomID)


async def get_members_directly(Client, pgsql: Spider_PGSQL, roomID: str) -> bool:
    """ get user list without joining the room.
    
    Note:
        An empty member list will be returned if the bridge room
        turned off this access manually.

    """
    resp_members = await nio_members(Client, roomID, True)

    if resp_members != False:
        pgsql.updateBridgeRoom(roomID)

        servers, user_ids = extract_HS_From_UsrInfo(resp_members)
        # See Note
        if len(user_ids) == 0:
            return False

        print("    Get new servers {}".format(len(servers)) )
        pgsql.addServers(servers)
        pgsql.addUids(user_ids)

        return True
    
    return False

