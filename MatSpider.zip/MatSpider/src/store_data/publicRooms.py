# Bare implementation of [publicRooms API].
# However, we pour the received data into pgsql 
# databse, rather than just regard them as return value.
# The HTTP request is based on the python requests module.
#
# TODO: wrap the api as class.
# LAST MODYFIED: 2022 / 11 / 07

import requests

from sys import exit
from typing import *

from ..api_database import Spider_PGSQL


################################### hyper-parameter ###################################
# remove TLS warning
requests.packages.urllib3.disable_warnings()

ERROR_STATE_TYPE = int

SUCCESS = 0
FORBIDDEN = 1
FAIL = 2
REQUEST_FAIL = 3

retry = 3
timeout = 10

# We use matrix.org as the default server for stability.
# token is from @wybpip:matrix.org
default_access_token = "syt_d3licGlw_SmJyQwMrRvvQtrnraqNF_1119IJ"
if default_access_token == None:
    print("fill in the default_access_token in publicRooms.py")
    exit(1)


######################################### API ###############################################

def collect_publicRooms(
    HS_Remote: str, 
    pgsql: Spider_PGSQL, 
    access_token: str = default_access_token, 
    HS_Local: str = "https://matrix-client.matrix.org",
    include_all_networks: bool = False,
    limit: "int" = 50,  
    batchID: str = None, 
    continuity: bool = True
    ) -> ERROR_STATE_TYPE:
    """ get batches of public rooms on HS_Remote(each batch has its unique batchID) and handle error.

    paras:  
        HS_Local: the [actual domain] of your Matrix Server, not well known url.
        limit   : the size of one public room batch. if limit == None, 
                it means to get all public rooms in one batch.
        batchID : the batch you specify. if batchID == None, it means to get the first batch.
        turn continuity to True to get the following batches iteratively.

    ret: 
        ERROR_STATE_TYPE.

    """
    httpRequest = constructHttpRequest(
        access_token, 
        HS_Local[8:], 
        HS_Remote, 
        limit, 
        batchID, 
        include_all_networks
        )

    while True:
        # Send http request
        # key step: update batchID
        httpRequest[3]["since"] = batchID
        batchID, errorCode = handleOneRequest(httpRequest, pgsql)
        
        # Check and handle potential error
        errorHandleResult = errorHandler(errorCode, httpRequest, pgsql)
        if errorHandleResult != SUCCESS:
            return errorReturn(HS_Remote, errorHandleResult, pgsql)
        
        # Successfully get all public roomids.
        if not continuity or batchID == None:
            pgsql.updateServerInfo(HS_Remote, SUCCESS)
            return SUCCESS


################################### Interaction Modules ###################################
def constructHttpRequest(
    access_token: str,
    HS_Local: str,
    HS_Remote: str, 
    limit: "int", batchID:"str",
    include_all_networks: "bool"
    ) -> List:
    """ The accessory function of generating HTTP packet data.

    Ret: 
        url, params, headers, postData
    
    Note:
        paras will be removed automaticly if None

    """

    if "Bearer" not in access_token:
        access_token = "Bearer " + access_token

    url = "{}{}{}".format(r'https://', HS_Local, r"/_matrix/client/r0/publicRooms")
    params = { 
        "server": HS_Remote 
        }
    headers = {
        "accept": "application/json", 
        "content-type": "application/json",
        "Authorization": access_token, 
        }
    postData = {
        "limit": limit, 
        "since": batchID, 
        "include_all_networks": include_all_networks
        }
    
    return url, params, headers, postData


def sendPacket(url, params, headers, postData) -> Union[requests.Response, ERROR_STATE_TYPE]:
    """ The accessory function of making https request.
    retry when requests.exceptions.RequestException occurs.

    """
    for _ in range(retry):
        try:
            response = requests.post(
                url=url, 
                json=postData, 
                verify=False, 
                headers=headers, 
                params=params, 
                timeout=timeout
                )
            return response
        except:
            # resend
            continue  
    
    # Eventually, fail to get a response
    return REQUEST_FAIL


def write_RoomInfo_to_DB(responseData: Dict, pgsql: "Spider_PGSQL") -> List:
    """ parse the JSON and write roomID, 
    num_members... into the database.

    Ret:
        fail -> ret [None, errorCode]
        sunccess -> print public rooms, ret [batchID, None]

    """
    
    # extract batchID and errorCode
    batchID = responseData.get("next_batch", None)
    errorCode = responseData.get("errcode", None)
    
    if errorCode:
        # ret type -> None, errorcode
        return batchID, errorCode  
    else:
        # -> list(Dict)
        responseData = responseData["chunk"]
        # format- [[roomid, num_members], ...]
        batch_rooms = []

        for obj in responseData:
            room_id = obj["room_id"]
            num_members = obj["num_joined_members"]
            if room_id != "":
                batch_rooms.append([room_id, num_members])
        
        pgsql.addRooms(batch_rooms)
        return batchID, None
    

def handleOneRequest(httpData: List, pgsql) -> List:
    """ The accessory function of making one request and receiving reception.

    ret: 
        url, params, headers, postData

    """
    response = sendPacket(*httpData)

    # communication ERROR_STATE["REQUEST_FAIL"]
    if response == REQUEST_FAIL:
        return None, REQUEST_FAIL
    
    else:
        # compatiblity with matrix.org features.
        # cloudfare will return 502 without JSON.
        try:
            responseData = response.json()
        except:
            return None, FAIL
        
        batchID, errorCode = write_RoomInfo_to_DB(responseData, pgsql)
        return batchID, errorCode


################################## Handle errors ##################################
def errorHandler(errorCode: str, httpData: List, pgsql: Spider_PGSQL) -> ERROR_STATE_TYPE:
    """handle request error and errorCode
    
    """
    # handle communication error
    if errorCode == REQUEST_FAIL:
        return REQUEST_FAIL
    
    # handle errorCode
    if errorCode == None:
        return SUCCESS
    elif errorCode == "M_FORBIDDEN":
        return FORBIDDEN
    elif errorCode == "M_UNKNOWN_TOKEN":
        print("Warning: Token is invalid!")
        print("Exit")
        exit(1)
    else:
        return unknownErrorHandler(httpData, pgsql)


def unknownErrorHandler(httpData: List, pgsql) -> ERROR_STATE_TYPE:
    for _ in range(retry):
        __, errorCode = handleOneRequest(httpData, pgsql)
        if errorCode == None:
            return SUCCESS
        if errorCode == "FORBIDDEN":
            return FORBIDDEN
    return FAIL


def errorReturn(HS_Remote: str, errorHandleResult: int, pgsql: Spider_PGSQL) -> ERROR_STATE_TYPE:
    """return errorCode, record relative error info 
    and update table - server.
    
    """
    if errorHandleResult == FORBIDDEN:
        pgsql.updateServerInfo(HS_Remote, errorHandleResult)
        return FORBIDDEN
    elif errorHandleResult == REQUEST_FAIL:
        return REQUEST_FAIL
    elif errorHandleResult == FAIL:
        return FAIL
