#!/usr/local/bin/python3

import asyncio
from os import system
from os.path import exists
from time import strftime, localtime

from src import spider

asyncio.get_event_loop().run_until_complete(spider())

# move the error log file
time = strftime("%m%d%H%M-", localtime())
if exists('Error.log'):
    system("mv Error.log  ../ErrorLog/{}Error-local.log".format(time))
